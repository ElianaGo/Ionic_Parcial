import { Component, OnInit } from '@angular/core';
import { PhotosService } from './photos.service';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage implements OnInit { //se implementò el OnInit para poner utilizar el ngoninit

  photos=  [];

  constructor(private photosService : PhotosService) {}

  ngOnInit(){ //lo que hara es que cuando cargue la aplicaciòn, vamos a mostrar los datos en pantalla
    this.photosService.getPhotos().subscribe(data=>{
      this.photos=data;
    })

  }

  

}
