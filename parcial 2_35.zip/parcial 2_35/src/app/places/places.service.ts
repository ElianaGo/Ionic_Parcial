import { Injectable } from '@angular/core';
import { Place } from './place.model';

@Injectable({
  providedIn: 'root'
})
export class PlacesService {

  private places: Place []= [
    {
      id: '1',
      title: 'Gran Muralla, China',
      imageURL: 'https://tipsparatuviaje.com/wp-content/uploads/2019/08/gran-muralla-china.jpg',
      comments: ['Esta fortificación de 212 mil km, de la que se conserva aproximadamente 1/3, es la construcción en su tipo más grande del mundo y uno de los iconos turísticos de China.', 'La obra unía la frontera chino-coreana con el desierto de Gobi y fue construida como protección contra pueblos chinos hostiles y enemigos extranjeros, entre los siglos V a.C. y XVI']
    
    },
    {
      id: '2',
      title: 'Gran Pirámide de Guiza, Egipto',
      imageURL: 'https://tipsparatuviaje.com/wp-content/uploads/2019/08/gran-piramide-de-guiza-egipto.jpg',
      comments: ['En la Necrópolis de Guiza, a 14 km al suroeste de El Cairo, hallarás las pirámides Micerinos, Kefrén y Keops, esta última la más atractiva para los turistas pues es la única de las Siete Maravillas del Mundo Antiguo que se mantiene en pie. Además, es la mayor de las pirámides egipcias y fue la construcción más alta del planeta por casi 4 milenios.']
    },

    {
      id: '3',
      title: 'La Alhambra, Granada, España',
      imageURL: 'https://tipsparatuviaje.com/wp-content/uploads/2019/08/la-alhambra-granada-espana.jpg',
      comments: ['El monumento español más visitado después del Templo Expiatorio de la Sagrada Familia.', 'Esta ciudadela andalusí Patrimonio de la Humanidad y en la que vivían el rey nazarí y su corte, está formada por palacios, bellos jardines y un alcázar.']
    
    },
    {
      id: '4',
      title: 'Torre Eiffel, París, Francia',
      imageURL: 'https://tipsparatuviaje.com/wp-content/uploads/2019/08/torre-eiffel-paris-francia.jpg',
      comments: ['La torre más famosa del mundo tiene una altura arquitectónica de 300 metros, elevándose a 324 metros al incluir su antena. Tiene 3 plantas situadas respectivamente a 57.6, 115.7 y 276.1 metros de la base, las que puedes alcanzar subiendo sus más de 1600 escalones o en ascensores.']
    },
    {
      id: '5',
      title: 'Hollywood Sign, Los Ángeles, EE.UU',
      imageURL: 'https://tipsparatuviaje.com/wp-content/uploads/2019/08/hollywood-sign-los-angeles-eeuu.jpg',
      comments: ['Lo que comenzó en 1923 como un enorme anuncio comercial para promocionar un desarrollo inmobiliario, se convirtió en la principal postal turística de Los Ángeles, California.', 'El letrero de Hollywood ha sido escenario de suicidios, accidentes automovilísticos, actos de vandalismo y de filmaciones de cine y televisión. Pocos turistas, quizás ninguno, habrá dejado Los Ángeles sin hacerle una foto.']
    },
    {
      id: '6',
      title: 'Templo Expiatorio de la Sagrada Familia, Barcelona, España',
      imageURL: 'https://tipsparatuviaje.com/wp-content/uploads/2019/08/templo-expiatorio-de-la-sagrada-familia-barcelona-espana.jpg',
      comments: ['La obra cumbre del arquitecto español del siglo XIX, Antoni Gaudí, gran maestro del modernismo, es una de la catedrales más fotografiadas del mundo.', 'El templo consta de 5 naves centrales y 3 fachadas dedicadas al Nacimiento, la Pasión y Muerte y la Resurrección de Jesús. Cuando haya sido terminada tendrá 18 torres, una para cada apóstol, 4 para los evangelistas, una para la Virgen y una para Jesús.']
    },
    {
      id: '7',
      title: 'Torre de Pisa, Italia',
      imageURL: 'https://tipsparatuviaje.com/wp-content/uploads/2019/08/torre-de-pisa-italia.jpg',
      comments: ['Entre los lugares turísticos del mundo, este es el que ha demandado más atención para evitar el colapso.', 'Es una joya del arte románico que empezó a inclinarse tan pronto comenzó su construcción en 1173. Desde entonces, se ha inclinado en micromovimientos, lo que ameritó su cierre y reforzamiento en 1990.']
    },
    {
      id: '8',
      title: 'Gran Palacio de Bangkok, Tailandia',
      imageURL: 'https://tipsparatuviaje.com/wp-content/uploads/2019/08/gran-palacio-de-bangkok-tailandia.jpg',
      comments: ['El monumento arquitectónico más importante de Tailandia fue mandado a construir en los años 1790 por el rey de Siam, Rama I el Grande. Está protegido por un lado por el río Chao Phraya y por el otro por un canal construido con propósitos defensivos, por lo que parece estar en una isla.']
    },
    {
      id: '9',
      title: 'Monte Fuji, Japón',
      imageURL: 'https://tipsparatuviaje.com/wp-content/uploads/2019/08/monte-fuji-japon.jpg',
      comments: ['El principal símbolo geográfico japonés visible desde Tokio con tiempo despejado. Sus 3.776 metros sobre el nivel del mar le convierten en la máxima cima de Japón, lugar sagrado y centro de entretenimiento.', 'Es un volcán considerado activo pero de bajo riesgo eruptivo. Su última actividad se registró en 1707.']
    }



  ]


  constructor() { }

  getPlaces(){
    return[...this.places]
  }

  getPlace(placeId: string){
    return{
      ...this.places.find(place =>{
        return place.id === placeId
      })
    }
  }

  addPlace(title: string, imageURL: string, comments: []){
    this.places.push({
      title,
      imageURL,
      comments,
      id: this.places.length + 1 + ""
    })
  }

  deletePlace(placeId: string){
    this.places = this.places.filter(place=>{
      return place.id !=placeId;
    })
  }
}
