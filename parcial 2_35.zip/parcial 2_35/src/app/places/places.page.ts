import { Component, OnInit } from '@angular/core';
import { Comment } from '@angular/compiler';
import {PlacesService} from './places.service'
import { Router } from '@angular/router';

@Component({
  selector: 'app-places',
  templateUrl: './places.page.html',
  styleUrls: ['./places.page.scss'],
})
export class PlacesPage implements OnInit {

  places = []

  constructor(private placeService: PlacesService, private router: Router) { }

  ngOnInit() { //evento que carga los datos la primera vez
    this.places= this.placeService.getPlaces();

  }
  
  ionViewWillEnter(){ //carga los datos cuando el componente vuelve a ser visitado

    this.places = this.placeService.getPlaces();

  } 

  addNewPlace(){
    this.router.navigate(['/new-place'])
  }

  goToHome(){
    this.router.navigate(['/home'])
  }



}
