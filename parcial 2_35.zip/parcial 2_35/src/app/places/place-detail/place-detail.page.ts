import { Component, OnInit, ɵConsole } from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router'; //el router permite navegar
import { PlacesService } from '../places.service'; //se importa el servicio donde estan los datos y los metodos centralizados
import { AlertController } from '@ionic/angular';// alertas
import { Place } from '../place.model'; //se importa la interfaz 

@Component({
  selector: 'app-place-detail',
  templateUrl: './place-detail.page.html',
  styleUrls: ['./place-detail.page.scss'],
})
export class PlaceDetailPage implements OnInit {

  place: Place; // se crea una propiedad place del tipo Place (interfaz)

  constructor(private activatedRoute: ActivatedRoute, private placeService: PlacesService, private router: Router, private alertCtrl: AlertController) { }

  ngOnInit() { //este funciona para que al cargar la pagina de page-detail, se obtenga el id de la ruta, y este nos sirva para llamar los datos de este id y guardarlos en la propiedad place
    this.activatedRoute.paramMap.subscribe(paramMap =>{
      const recipeId = paramMap.get('placeId')
      
      this.place = this.placeService.getPlace(recipeId);
      console.log(this.place)
    })
  }

  async deletePlace(){ // este metodo llama el metodo deletePlace del servicio para ser utilizado en el evento click del boton eliminar
    const alertElement = await this.alertCtrl.create({ // va a devolver un "componente html" que voy a poder mostrar, en este caso solo se crea y se guarda en una constante
      header:'Are you sure, do you want to delete it?',
      message: 'Be careful',
      buttons: [{
        text:'Cancel',
        role: 'cancel' //logica de ionic, lo que hará es cerrar la ventana si doy un clic en el boton cancel
      },
      {
        text:'Delete', 
        handler: () =>{  //es una función, adentro de pone la logica que queremos ejecutar al darle clic en delete
          this.placeService.deletePlace(this.place.id)
          this.router.navigate(['/places'])  
        }
      }
      ]

    });
    await alertElement.present(); //metodo asincrono que va a mostrar en pantalla la alerta
  }
}
