export interface Place {
    id: string,
    title: string,
    imageURL: string,
    comments: string[]
}